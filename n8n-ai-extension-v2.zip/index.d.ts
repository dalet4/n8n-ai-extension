import { INodeType, ICredentialType } from 'n8n-workflow';
export declare const nodeTypes: INodeType[];
export declare const credentialTypes: ICredentialType[];
export declare const registerCustomComponents: (uiExtension: any) => void;
