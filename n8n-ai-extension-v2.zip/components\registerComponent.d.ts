export declare function registerComponent(uiExtension: any): void;
